 // Initialize Firebase
 import firebase from 'firebase/app';
 import "firebase/auth";
 import "firebase/database";
 import "firebase/storage";
 
 
 var config = {
  apiKey: "AIzaSyBuZ_hqvz2Wpk2op0kb8yrlpABdydonWZ8",
  authDomain: "uber-b3274.firebaseapp.com",
  databaseURL: "https://uber-b3274.firebaseio.com",
  projectId: "uber-b3274",
  storageBucket: "uber-b3274.appspot.com",
  messagingSenderId: "297809925884"
};
firebase.initializeApp(config);

  export default firebase;