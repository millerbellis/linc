import React, {useContext, useReducer, useState, useEffect, Suspense, lazy} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import TodosContext from './context';
import todosReducer from './reducer';
import * as serviceWorker from './serviceWorker';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

 import NavBar from './components/navbar';
 import firebase from './firebase';
import Home from './Main/Caro';
import Login from './components/login';
import Signup from './components/register';
import Projects from './components/projects/projhome';
import Profile from './components/profile';


const App = () => {
   

    const initstate = useContext(TodosContext)
    const [state, dispatch] = useReducer(todosReducer, initstate)
    const user = state.user;
    const name = state.name;
 

    useEffect(() => {
        firebase.auth().onAuthStateChanged(user => {
            if(user){
                dispatch({
                    type:"SET_USER",
                    payload: user
                })
           
            
             } else {
                dispatch({
                    type:"SET_USER",
                    payload: ''
                })
        }
    })
    
},[])
    return(
        <>
        <TodosContext.Provider value={{state, dispatch, user, name}}>
            <NavBar/>
            {user ? (
             
                    //  <Projects/>
             ''
            ):(
            
                ''
                
            )}
            
       
        <Router>
      <Suspense fallback={<div>Loading...</div>}>
        <Switch>
        {user ? (
            <>
            <Route exact path="/loads" component={Projects}/>
            <Route exact path="/myprofile" component={Profile}/>
            </>
        ) : (
            <>
            <Route exact path="/" component={Home}/>
            <Route path="/login" component={Login}/>
            <Route path="/signup" component={Signup}/>
            </>
        )}
         
        </Switch>
      </Suspense>
    </Router>
    </TodosContext.Provider>
        </>
    )
}

ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
