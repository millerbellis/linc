import React from 'react';
import { Input, Image, Progress, Accordion, Icon,Container, Header } from 'semantic-ui-react'
import {Helmet} from 'react-helmet';
export default function Caro() {
  return(
  <>
    <Helmet 
 title= "LincFreight - Trucking Load Board"
 meta={[
  {"name": "description", "content": "Trucking Load Board"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "LincFreight - Trucking Load Board"},
  {property: "og:url", content: "https://LincFreight.com/"}
 ]}
/>
<div id="loader-wrapper">
        <div id="loader"></div>
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
    </div>

    <section class="banner-section3 relative" id="banner-section">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row align-items-center fullscreen">
                <div class="col-lg-6 col-md-7 banner-left">
                    <h1 class="text-uppercase">Hello, we're <br/> <span>Linc Freight</span></h1>
                    <p>We offer a free load board for any logistics company or driver to use! </p>
                    <a class="video-btn primary-btn" href="/signup">Sign up!</a>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section section-gap-full relative" id="about-section">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-6 col-md-12 about-left">
      
                </div>
                <div class="col-lg-5 col-md-12 about-right">
                    <h3>About Us</h3>
                    <h1>A Little About Us</h1>
                    <p>
                        A group of software developers that have worked in the trucking industry but always wanted to find a way to offer a free load board for all! Since we have started with Linc Freight we have been able to test this platform out and now offer it to everyone but, there's one thing... IT'S FREE!
                    </p>
                    <a class="primary-btn" href="/signup">Sign Up for free! </a>
                </div>
            </div>
        </div>
        <div class="floating-shapes">
            <span data-parallax='{"x": 150, "y": -20, "rotateZ":500}'>
                <img src="img/shape/fl-shape-1.png" alt=""/>
            </span>
            <span data-parallax='{"x": 250, "y": 150, "rotateZ":500}'>
                <img src="img/shape/fl-shape-2.png" alt=""/>
            </span>
            <span data-parallax='{"x": -180, "y": 80, "rotateY":2000}'>
                <img src="img/shape/fl-shape-3.png" alt=""/>
            </span>
            <span data-parallax='{"x": -20, "y": 180}'>
                <img src="img/shape/fl-shape-4.png" alt=""/>
            </span>
            <span data-parallax='{"x": 300, "y": 70}'>
                <img src="img/shape/fl-shape-5.png" alt=""/>
            </span>
            <span data-parallax='{"x": 250, "y": 180, "rotateZ":1500}'>
                <img src="img/shape/fl-shape-6.png" alt=""/>
            </span>
            <span data-parallax='{"x": 180, "y": 10, "rotateZ":2000}'>
                <img src="img/shape/fl-shape-7.png" alt=""/>
            </span>
            <span data-parallax='{"x": 60, "y": -100}'>
                <img src="img/shape/fl-shape-9.png" alt=""/>
            </span>
            <span data-parallax='{"x": -30, "y": 150, "rotateZ":1500}'>
                <img src="img/shape/fl-shape-10.png" alt=""/>
            </span>
        </div>
    </section>

    


     <section class="service-section section-gap-full">
        <div class="container">
            <div class="section-title">
                <h2 class="text-center">Our Services</h2>
                <p class="text-center">Discover all that Linc Freight has to offer!</p>
            </div>
            <div class="row owl-carousel" id="service-carusel">
                <div class="single-service">
                    <i class="ti-user"></i>
                    <h4>Load Board</h4>
                    <p>
                        A great load board to identify new business and quick!
                    </p>
                </div>
                <div class="single-service">
                    <i class="ti-announcement"></i>
                    <h4>Booking Loads</h4>
                    <p>
                        Booking loads has never been easier or faster. One button click and it will notify the broker that you want the load!
                    </p>
                </div>
                <div class="single-service">
                    <i class="ti-bar-chart"></i>
                    <h4>Past Loads</h4>
                    <p>
                       View past loads you have done!
                    </p>
                </div>
                <div class="single-service">
                    <i class="ti-palette"></i>
                    <h4>Great Customer Service!</h4>
                    <p>
                       Have any issues? No problem we are always here for you!
                    </p>
                </div>
                <div class="single-service">
                    <i class="ti-agenda"></i>
                    <h4>Always stored</h4>
                    <p>
                        Your data is never going away so don't worry about past loads no longer being there!
                    </p>
                </div>
               
            </div>
        </div>
    </section>

   
  </>
  )
}