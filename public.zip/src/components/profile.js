import React, {useState, useEffect, useContext, useReducer, usePrevious} from 'react';
import firebase from '../firebase';
import TodosContext from '../context';
import {Modal, ModalHeader, ModalBody,  Row, Col, CardTitle, Card, Alert} from 'reactstrap';
import { Input, Image, Progress, Accordion, Icon, Form, Checkbox, Label, Message,Menu, Segment, Header, Sidebar, Ref, Button, ButtonGroup } from 'semantic-ui-react'

import {Helmet} from 'react-helmet';
export default function Projects() {
const{state, dispatch, user, name} = useContext(TodosContext);
const [modal, setModal] = useState(false);
const [modal1, setModal1] = useState(false);
const [modal2, setModal2] = useState(false);
const [projName, setProjname] = useState('');
const [userRef, setUserRef] = useState(firebase.database().ref("users"))
const [projRef, setProjRef] = useState(firebase.database().ref("projects"))
const [bookRef, setBookRef] = useState(firebase.database().ref("booked"))
const [userid, setUserid] = useState('')
const [users, setUsers] = useState([])
const [uname, setUname] = useState('')

const [companyName, setCompanyName] = useState('')



useEffect(() => {
    getAll()
}, [])



const getAll = () => {
    let loads = [];
     userRef.on("child_added", snap => {
         loads.push(snap.val());
       setUsers(loads)
   
    
     })
 }
 
    return(
        <>
         <Helmet 
 title= "LincFreight - Profile"
 meta={[
  {"name": "description", "content": "Trucking Load Board"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "LincFreight - Profile"},
  {property: "og:url", content: "https://LincFreight.com/myprofile"}
 ]}
/>
        <TodosContext.Consumer>
      {value => 
     <>
         <div>{users.map((us) => {
        return   <>
            {value.name === us.name ? (
                <>
                 <Row className="mt-3 ml-3 mr-3 mb-3" >
                <Col sm="12" >
                <Message floating><b>{value.name}'s </b>Profile</Message>
           
                <form class="w-full max-w-sm">
                <div class="flex items-center border-b border-b-2 border-blue py-2">
                <input class="appearance-none bg-transparent border-none w-full text-grey-darker mr-3 py-1 px-2 leading-tight focus:outline-none"
                 type="text" 
                 defaultValue={us.name}
                 onChange={event => setUname(event.target.value)}
             
                  placeholder="Email Address"
                  />

                </div>
                <div class="flex items-center border-b border-b-2 border-blue py-2">
                <input class="appearance-none bg-transparent border-none w-full text-grey-darker mr-3 py-1 px-2 leading-tight focus:outline-none"
                 type="text" 
                 defaultValue={us.companyName}
                 onChange={event => setCompanyName(event.target.value)}
               
                  placeholder="Company Name"
                  />
                </div>
                <button class="bg-blue hover:bg-blue-light text-white font-bold mt-4 py-2 px-4 border-b-4 border-blue-dark hover:border-blue rounded">
                  Update
                </button>
                </form>
             
                </Col>
                </Row>
                </>
            ):('')}

      
         
    </>
         })}</div>

        </>
   
       
      }


      
        </TodosContext.Consumer>
</>

    )
}