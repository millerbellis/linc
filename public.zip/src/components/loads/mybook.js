import React, {useState, useEffect, useContext, useReducer, usePrevious} from 'react';
import firebase from '../../firebase';
import TodosContext from '../../context';
import {Modal, ModalHeader, ModalBody, Button, ButtonGroup, Row, Col, Label, CardTitle, Card, Alert} from 'reactstrap';
import { Input, Image, Progress, Accordion, Icon } from 'semantic-ui-react'
import mime from "mime-types";
import uuidv4 from 'uuid';
import {Helmet} from 'react-helmet';
export default function Projects() {
const{state, dispatch, user, name} = useContext(TodosContext);
const [modal, setModal] = useState(false);
const [modal1, setModal1] = useState(false);
const [projName, setProjname] = useState('');
const [userRef, setUserRef] = useState(firebase.database().ref("users"))
const [projRef, setProjRef] = useState(firebase.database().ref("projects"))
const [bookRef, setBookRef] = useState(firebase.database().ref("booked"))
const [userid, setUserid] = useState('')
const [projs, setProjs] = useState([])
const [projid, setProjid] = useState('');
const [cprojs, setCprojs] = useState(false);
const [vendore, setVendore] = useState('');
const [ven, setVen] = useState([])
const [activeVendAdd, setActiveVendAdd] = useState(0)
const [activeVend, setActiveVend] = useState(0)
const [activeUpload, setActiveUpload] = useState(0)
const [users, setUsers] = useState([])
const [vendProjs, setVendProjs] = useState([])
const [daddress, setDaddress] = useState('')
const [dzip, setDzip] = useState('')
const [saddress, setSaddress] = useState('')
const [szip, setSzip] = useState('')
const [miles, setMiles] = useState('')



 useEffect(() => {
    getAll()
   
    getAllUsers()

  }, [])

  const getAll = () => {
     let loads = [];
      projRef.on("child_added", snap => {
          loads.push(snap.val());
        setProjs(loads)
    
     
      })
  }

  const getAllUsers = () => {
    let loads = [];

     userRef.on("child_added", snap => {
       loads.push(snap.val());
       setUsers(loads)
        
     })
 }



  const handlePageChange = (pageid) => {
     // alert(pageid)
      setModal1(!modal1)
    // //window.location = "/project/project=" + pageid;
     setProjid(pageid)
    
    // const url = window.location.href;
    // seturlParam((url.slice(window.location.href.indexOf('=') + 1)))
    
  }

  const toggles1 = () => {
    setModal1(!modal1)
}

  const toggles = () => {
      setModal(!modal)
  }
  const handleSubmit = event => {
    event.preventDefault();
    //alert(userid)
    const key = uuidv4()

    const response = {
        id: userid,
        daddress: daddress,
        dzip: dzip,
        szip: szip,
        saddress: saddress,
        complete: 0,
        sdate: firebase.database.ServerValue.TIMESTAMP,
        edate:'',
        miles: miles
    }
    projRef
    .push(response)
    .then(() => {
        let keys = [];
      projRef.limitToLast(1).on("child_added", snap => {
        keys.push(snap.key);
        
        const response = {
            child: snap.key
        }
       projRef
        .child(snap.key)
        .update(response)
       
    getAll()
      })

        setModal(false)
        setProjname('')
       setDaddress('')
       setDzip('')
       setSzip('')
       setSaddress('')
       setMiles('')
    })
  }

  const handleUpdateSubmit = event => {
      event.preventDefault()

      let response = {};
      if(daddress) {
        response = {daddress: daddress}
      } else if(dzip) {
        response = {dzip: dzip}
      } else if(saddress){
        response = {saddress: saddress}
      } else if(szip){
        response = {szip: szip}
      } else if(miles){
        response = {miles: miles}
      } 
    if(daddress && dzip) {
        response = {daddress: daddress, dzip: dzip}
    }
    if(daddress && saddress){
        response = {daddress: daddress, saddress: saddress}
    }
    if(daddress && szip){
      response = {daddress: daddress, szip: szip}
      }
     if(daddress && miles){
        response = {daddress: daddress, miles: miles}
    }
    if(daddress && dzip && saddress){
      response = {daddress: daddress, dzip: dzip, saddress:saddress}
    }
    if(daddress && dzip && miles){
      response = {daddress: daddress, dzip: dzip, miles:miles}
    }
    if(daddress && dzip && saddress && szip){
      response = {daddress: daddress, dzip: dzip, saddress:saddress, szip:szip}
    }
    if(daddress && dzip && saddress && szip && miles){
      response = {daddress: daddress, dzip: dzip, saddress:saddress, szip:szip, miles:miles}
    }
    if(saddress && szip) {
      response = {saddress: saddress, szip: szip}
      }
      if(saddress && dzip) {
        response = {saddress: saddress, dzip: dzip}
    }
      if(szip && dzip) {
        response = {szip: szip, dzip: dzip}
      }
    if(saddress && miles) {
      response = {saddress: saddress, miles: miles}
  }
  if(saddress && miles && szip) {
    response = {saddress: saddress, miles: miles, szip: szip}
}


   projRef
    .child(projid)
    .update(response)
   
    setModal1(!modal1)
    setModal(false)
    setProjname('')
    getAll()
    setDaddress('')
    setDzip('')
    setSzip('')
    setSaddress('')
    setMiles('')
  }

const completeProj = (pro) => {
  const response = {
   complete: 1,
   edate: firebase.database.ServerValue.TIMESTAMP
  }

  projRef
    .child(pro)
    .update(response)
    .then(() => {
      setModal1(false)
      getAll()
    })
}

const bookLoad = (pro, use) => {
  const response = {
   id: use,
   loadid: pro,
   bookDate: firebase.database.ServerValue.TIMESTAMP
  }

  bookRef
    .push(response)
    .then(() => {
      setModal1(false)
      getAll()
    })
}



    return(
        <>
         <Helmet 
 title= "LincFreight - Loads"
 meta={[
  {"name": "description", "content": "project managent software"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "LincFreight - Loads"},
  {property: "og:url", content: "https://LincFreight.club/loads"}
 ]}
/>
        <TodosContext.Consumer>
      {value => 
     <>
 
             <button 
             onClick={toggles}
             style={{backgroundColor:'#4b4d51' , color:'white'}}
               className=" hover:bg-grey-lightest text-grey-darkest font-semibold ml-8 mt-3 py-2 px-4 border border-grey-light rounded shadow">
                   Add Load 
               </button>
               <button 
             onClick={() => setCprojs(!cprojs)}
             style={{backgroundColor:'#4b4d51', color:'white'}}
               className=" hover:bg-grey-lightest text-grey-darkest font-semibold ml-8 mt-3 py-2 px-4 border border-grey-light rounded shadow">
               {cprojs === false ? (
                  'Completed Loads'
               ): (
                  'All Loads'
               )}
                  
               </button>
        

  

 
 <div>{users.map((us) => {
        return   <>
        {us.name === value.name  ? (
         <div>{projs.map((answer) => {
          return   <>
          
          {answer.complete === 0  ? (
            <div>{vendProjs.map((vend) => {
              return   <>
              {vend.projid === answer.child && vend.email === us.name ? (
                <Row className="mt-3 ml-3 mr-3 mb-3" >
                <Col sm="12" >
                  <Card body style={{boxShadow: '0px 5px 4px' , backgroundColor:'#4b4d51'}}>
                    <CardTitle style={{color:'white'}}><Label >To </Label> <b>{answer.daddress}</b><Label >From </Label> <b>{answer.saddress}</b></CardTitle>
                    <CardTitle style={{color:'white'}}><Label >Total miles: </Label> <b>{answer.miles}</b></CardTitle>
         
                    <button 
        onClick={() => handlePageChange(answer.child)}
        style={{backgroundColor:'#00ffa9'}}
        className=" hover:bg-grey-lightest text-grey-darkest font-semibold  mt-3 py-2 px-4 border border-grey-light rounded shadow">
            View Project
        </button>
       
                  </Card>
                </Col>
          
              </Row>
              ): (
                ''
              )}
                
              </>
        })}</div>
          ) : (
            ''
          )}
            
        </>
        })}</div>
      //   </>
      // })}</div>
  ): (
    ''
     
     )}
     </>
})}</div>

   
  
        <Modal isOpen={modal} toggle={toggles}  style={{boxShadow: '0px 5px 4px'}}>
                <ModalHeader style={{backgroundColor:'#4b4d51', color:'white'}} toggle={toggles}>Add a Load</ModalHeader>

                <ModalBody>
                <form onSubmit={handleSubmit} className="w-full max-w-xs">
                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={value.user}
                        hidden='true'
                        onChange={event => setUserid(value.name)}
                        />
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                        Destination Address
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={daddress}
                        onChange={event => setDaddress(event.target.value)}
                        placeholder="Destination Address.."/>
                    </div>
                </div>

                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                       Destination Zip
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={dzip}
                        onChange={event => setDzip(event.target.value)}
                        placeholder="Destination Zip.."/>
                    </div>
                </div>

                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                        Start Address
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={saddress}
                        onChange={event => setSaddress(event.target.value)}
                        placeholder="Start Address.."/>
                    </div>
                </div>
                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                        Start Zip
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={szip}
                        onChange={event => setSzip(event.target.value)}
                        placeholder="Start Zip.."/>
                    </div>
                </div>
                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                        Miles
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={miles}
                        onChange={event => setMiles(event.target.value)}
                        placeholder="Total Miles.."/>
                    </div>
                </div>
                <div className="items-stretch">
                    <div className="center">
                    <button style={{backgroundColor:'#4b4d51'}} onClick={event => setUserid(value.name)} className="shadow hover:bg-purple-light focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type="submit">
                    Add Load
                    </button>
                    </div>
                </div>
                </form>
        </ModalBody>

        </Modal>
        <div>{projs.map((answer) => {
        return <>
        {projid === answer.child ? (
           <Modal isOpen={modal1} toggle={toggles1}  style={{boxShadow: '0px 5px 4px'}}>
           <ModalHeader style={{backgroundColor:'#4b4d51', color:"white"}} toggle={toggles1}>Load by: {answer.id}</ModalHeader>

           <ModalBody >
               <form onSubmit={handleUpdateSubmit}>
           <div className="md:flex md:items-center mb-3">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Destination Address
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={answer.daddress}
        onChange={event => setDaddress(event.target.value)}
      type="text"/>
   
    </div>
     </div>

       <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Destination Zip
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={answer.dzip}
        onChange={event => setDzip(event.target.value)}
      type="text"/>
   
    </div>
     </div>
   
    
     <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Start Address
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={answer.saddress}
        onChange={event => setSaddress(event.target.value)}
      type="text"/>
   
    </div>
     </div>

            <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Start Zip
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={answer.szip}
        onChange={event => setSzip(event.target.value)}
      type="text"/>
   
    </div>
     </div>

       <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
       Total Miles
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={answer.miles}
        onChange={event => setMiles(event.target.value)}
      type="text"/>
   
    </div>
     </div>

     <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Start Date
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={Date(answer.sdate)}
        disabled={true}
      type="text"/>
   
    </div>
     </div>
        {answer.complete === 1 ? (
          <>
           <div className="md:flex md:items-center mb-6">
           <div className="md:w-1/3">
             <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
               Complete Date
             </label>
           </div>
           <div className="md:w-2/3">
             <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
               defaultValue={Date(answer.edate)}
               
             type="text"/>
          
           </div>
            </div>
            </>
        ) : (
          <>
      
        {value.name === answer.id ? (

              
          <>
          <button 
          type="submit"
          style={{backgroundColor:'#4b4d51',color:'white'}}
          className=" hover:bg-grey-lightest text-grey-darkest font-semibold  py-2 px-4 border border-grey-light rounded shadow">
                Update 
          </button>
          <button 
          type="submit"
          onClick={() => completeProj(answer.child)}
          style={{backgroundColor:'white', marginLeft:'10px', color:'black'}}
          className=" hover:bg-grey-lightest text-grey-darkest font-semibold  py-2 px-4 border border-grey-light rounded shadow">
                Load Complete
          </button>
          </>
          
         
           ) : (
            <button 
          type="submit"
          onClick={() => bookLoad(answer.child, value.name)}
          style={{backgroundColor:'#62e09b', marginLeft:'10px', color:'white'}}
          className=" hover:bg-grey-lightest text-grey-darkest font-semibold  py-2 px-4 border border-grey-light rounded shadow">
                Book Load
          </button>
        )}
         
          </>
        )}
    
    </form>


   

              
 
   </ModalBody>

   </Modal> 
        )
        : (
        ''
        )}
         
        </>
        })}</div>




         {cprojs === false ? (
            <div>{projs.map((answer) => {
              return   <>
              {answer.complete === 0 ? (
                    <Row className="mt-3 ml-3 mr-3 mb-3" >
                    <Col sm="12" >
                      <Card body style={{boxShadow: '0px 5px 4px' , backgroundColor:'white'}}>
                      <CardTitle style={{color:'black'}}><Label >From </Label> <b>{answer.saddress} </b><Label > To </Label> <b>{answer.daddress}</b></CardTitle>
                    <CardTitle style={{color:'black'}}><Label >Total miles: </Label> <b>{answer.miles}</b></CardTitle>
         
             
                        <button 
            onClick={() => handlePageChange(answer.child)}
            style={{backgroundColor:'#4b4d51', color:'white'}}
            className=" hover:bg-grey-lightest text-grey-darkest font-semibold  mt-3 py-2 px-4 border border-grey-light rounded shadow">
                View Load
            </button>
           
                      </Card>
                    </Col>
              
                  </Row>
              
              ) : (
                ''
              )}
                
              </>
            })}</div>
        ): (
          ''
        )}


        {cprojs === true ? (
            <div>{projs.map((answer) => {
              return   <>
              { answer.complete === 1 && value.name === answer.id ? (
                    <Row className="mt-3 ml-3 mr-3 mb-3">
                    <Col sm="12" >
                    <Card body style={{boxShadow: '0px 5px 4px' , backgroundColor:'white'}}>
                      <CardTitle style={{color:'black'}}><Label >From </Label> <b>{answer.saddress} </b><Label > To </Label> <b>{answer.daddress}</b></CardTitle>
                    <CardTitle style={{color:'black'}}><Label >Total miles: </Label> <b>{answer.miles}</b></CardTitle>
         
             
                        <button 
            onClick={() => handlePageChange(answer.child)}
            style={{backgroundColor:'#4b4d51', color:'white'}}
            className=" hover:bg-grey-lightest text-grey-darkest font-semibold  mt-3 py-2 px-4 border border-grey-light rounded shadow">
                View Load 
            </button>
                      </Card>
                    </Col>
              
                  </Row>
              
              ) : (
                ''
              )}
                
              </>
            })}</div>
        ): (
          ''
        )}
        



         
        </>
   
       
      }


      
        </TodosContext.Consumer>
</>

    )
}