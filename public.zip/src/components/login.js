import React, {useState, useEffect, useContext, useReducer,Suspense} from 'react';
import firebase from '../firebase';
import TodosContext from '../context';
import todosReducer from '../reducer';
import {Helmet} from 'react-helmet';
import { withRouter,BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import axios from 'axios';
import Projects from './projects/projhome';


export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [test, setTest] = useState('');



    const  handleSubmit  = event  => {
        event.preventDefault()
       firebase
       .auth()
       .signInWithEmailAndPassword(email, password)
       .then(signedInUser => {
    
         
        window.location.href='/loads'
     
        
       })
       .catch(err => {
           console.error(err);
           setError(err);
       })

      
    }

  
    const{state, dispatch} = useContext(TodosContext);
    return(
        <>

        <Helmet 
 title= "LincFreight - Login"
 meta={[
  {"name": "description", "content": "login for LincFreight - Trucking Load Board"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "LincFreight - Login"},
  {property: "og:url", content: "https://LincFreight.com/login"}
 ]}
/>
        <div className="flex justify-center">

     <div className=" justify-center max-w-sm rounded  shadow-lg">
 
 <div className=" text-center px-6 py-4">
      <TodosContext.Consumer>
      {value => <div className="font-bold text-xl mb-2">Login {value.user}</div>}
      </TodosContext.Consumer>
   
   <form onSubmit={handleSubmit} className="w-full max-w-xs">
   <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
        Email 
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-red"
        type="text"
        value={email}
        onChange={event => setEmail(event.target.value)}
        placeholder="info@LincFreight.com"/>
    </div>
  </div>

  <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
        Password
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-red" 
       type="password"
       value={password}
        onChange={event => setPassword(event.target.value)}
        placeholder="Password"/>
    </div>
  </div>
  <div className="md:flex md:items-center">
    <div className="md">
     
      <button 
      
      style={{backgroundColor:'#4b4d51'}} className="shadow  hover:bg-purple-light focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type="submit">
       Login
      </button>
    </div>
  </div>
   </form>
 </div>

</div>

</div>





</>

    )
}